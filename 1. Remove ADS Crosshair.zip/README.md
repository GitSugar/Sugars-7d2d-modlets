# ADS Crosshair removal.
Totally subjective removal of ads crosshairs so the iron sights and reflex sight have more of a purpose other than a slight dps increase and visuals.

## Instalation
It's a modlet, you just drop it into your {steap_path}/common/7 Days To Die/mods folder.
Make sure it isn't nested. Inside the mods folder there should be a '1. Remove ADS Crosshair' folder with THIS README inside it.